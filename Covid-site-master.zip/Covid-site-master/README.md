# Covid-site
This is my first web project. I used only HTML5 and CSS3 here. I had not used Javascript before but now when I learnt javascript I tried to make my page more alive.
Hence HTML5 CSS3 and JavaScript is used in this.
